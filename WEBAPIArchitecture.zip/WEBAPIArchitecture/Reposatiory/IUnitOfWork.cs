﻿namespace ReposatioryLayer
{
    public interface IUnitOfWork<T> : IDisposable where T : class
    {
        //This Interface is Used for get All Reposatiory Genric Type 
       // IAsynReposatiory<TEntity> GetAsynReposatiory<TEntity>() where TEntity : class;
       // IReposatiory<TEntity> GetReposatiory<TEntity>() where TEntity : class;
        IAsynReposatiory<T> asynReposatiory { get; }
        IReposatiory<T> reposatiory { get; }
    }
}
