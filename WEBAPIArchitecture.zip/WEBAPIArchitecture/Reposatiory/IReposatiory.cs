﻿
namespace ReposatioryLayer
{
    public interface IReposatiory<T>
    {
        public T GetById(int id);
        public T GetByStringId(string id);
        public bool Delete(T entity);   
        public bool Update(T entity);
        public T Add(T entity);
        public IEnumerable<T> GetAll();

    }
}
