﻿using DomianLayer.EntityViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ReposatioryLayer.DataBaseEntity;
using System.Net;

namespace WebApiArchitechture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        #region <Property>
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly UserManager<ApplicationUser> _userManager;
        #endregion

        #region <Contructor>
        public AccountController(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager)
        {
            _signInManager = signInManager;
            _userManager = userManager;
        }
        #endregion
        #region <GET Methods>

        #endregion

        #region <POST Methods>
        [HttpPost(nameof(LogIn))]
        public async Task<IActionResult> LogIn(LoginViewModel logInModel)
        {
            LoginViewModel objLogInModel;
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (logInModel != null)
                {
                    var getUserByUserName = await _userManager.FindByNameAsync(logInModel.UserName);
                    if (getUserByUserName != null)
                    {
                        if (await _userManager.CheckPasswordAsync(getUserByUserName, logInModel.Password) == true)
                        {
                            var result = await _signInManager.PasswordSignInAsync(getUserByUserName, logInModel.Password, false, false);
                            if (result.Succeeded)
                            {
                                objLogInModel = new LoginViewModel()
                                {
                                    UserName = logInModel.UserName,
                                    Token = string.Empty,
                                };
                                responseModel.Data = objLogInModel;
                                responseModel.Message = "Login Successfully";
                                responseModel.Code = (int)HttpStatusCode.OK;
                                return Ok(responseModel);
                            }
                            else if (result.IsLockedOut)
                            {
                                
                            }
                            else if (result.RequiresTwoFactor) 
                            { 

                            }
                            else
                            {
                                responseModel.Message = "Incorrect UserName And Password";
                                responseModel.Code = (int)HttpStatusCode.Unauthorized;
                                return Ok(responseModel);
                            }
                        }
                        else
                        {
                            responseModel.Message = "Incorrect UserName And Password";
                            responseModel.Code = (int)HttpStatusCode.Unauthorized;
                            return Ok(responseModel);
                        }
                    }
                    else
                    {
                        responseModel.Message = "Not Found";
                        responseModel.Code = (int)HttpStatusCode.NotFound;
                        return Ok(responseModel);
                    }
                }
                else
                {
                    responseModel.Message = "Enter UserName And PassWord";
                    responseModel.Code = (int)HttpStatusCode.NotFound;
                }
                return Ok(responseModel);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost(nameof(LogOut))]
        public async Task<IActionResult> LogOut()
        {
            ResponseModel responseModel = new ResponseModel();
            await _signInManager.SignOutAsync();
            responseModel.Code = (int)HttpStatusCode.OK;
            responseModel.Message = "Logout Successfully";
            return Ok(responseModel);

        }
        #endregion
    }
}
