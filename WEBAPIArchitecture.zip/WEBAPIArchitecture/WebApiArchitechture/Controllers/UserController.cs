﻿using AutoMapper;
using DomianLayer.EntityViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ReposatioryLayer.DataBaseEntity;
using System.Net;

namespace WebApiArchitechture.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        #region <Property>
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IMapper _mapper;
        #endregion

        #region <Contructor>
        public UserController(UserManager<ApplicationUser> userManager, IMapper mapper)
        {
            _userManager = userManager;
            _mapper = mapper;
        }
        #endregion
        #region <GET Methods>

        #endregion

        #region <POST Methods>
        [HttpPost(nameof(AddOrUpdateUser))]
        public async Task<IActionResult> AddOrUpdateUser(UserViewModel user)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                #region <Add User>
                var checkUser = await _userManager.FindByEmailAsync(user.Email).ConfigureAwait(false);
                if (checkUser == null)
                {
                    var mapUser = _mapper.Map<ApplicationUser>(user);
                    mapUser.TwoFactorEnabled = user.TwoFactorEnabled;
                    mapUser.Id = Guid.NewGuid();
                    var resultEntity = await _userManager.CreateAsync(mapUser, user.Password).ConfigureAwait(false);
                    if (resultEntity.Succeeded)
                    {
                        responseModel.Data = resultEntity;
                        responseModel.Message = "User Created Successfully";
                        responseModel.Code = (int)HttpStatusCode.OK;
                        return Ok(responseModel);
                    }
                    else
                    {
                        responseModel.Message = "Something Wents Worng";
                        responseModel.Code = (int)HttpStatusCode.InternalServerError;
                        return Ok(responseModel);
                    }

                }
                #endregion

                #region <Update User>
                else
                {
                    checkUser.Address = user.Address;
                    checkUser.FirstName = user.FirstName;
                    checkUser.LastName = user.LastName;
                    var result = await _userManager.UpdateAsync(checkUser).ConfigureAwait(false);
                    if (result.Succeeded)
                    {
                        responseModel.Message = "Update Successfully";
                        responseModel.Code = (int)HttpStatusCode.OK;
                    }
                    else
                    {
                        responseModel.Message = "Something Wents Worng";
                        responseModel.Code = (int)HttpStatusCode.InternalServerError;
                    }
                    return Ok(responseModel);
                }
                #endregion

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion
    }
}
