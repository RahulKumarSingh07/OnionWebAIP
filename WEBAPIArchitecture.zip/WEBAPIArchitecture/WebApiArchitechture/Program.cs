using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ReposatioryLayer.DataBaseEntity;
using WebApiArchitechture.AllDependencyServices;
using WebApiArchitechture.Mapping;

var builder = WebApplication.CreateBuilder(args);
string connString = builder.Configuration.GetConnectionString("DefaultConnection");
// Add services to the container.
#region <AutoMapper>
builder.Services.AddAutoMapper(typeof(ApplicationMapping));
#endregion
builder.Services.AddControllers();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseSqlServer(connString);
});
#region <Add Identity>
builder.Services.AddIdentity<ApplicationUser,IdentityRole<Guid>>(options =>
{
    options.User.RequireUniqueEmail = true;
    
}).AddEntityFrameworkStores<ApplicationDbContext>()
 .AddDefaultTokenProviders();
#endregion
#region <All Inject Services>
DependencyInjectionServices.AllDependencyServices(builder);
#endregion
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
